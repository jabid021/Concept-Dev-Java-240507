package formation.conceptdev.formationSpringboot.dto.request;

import org.antlr.v4.runtime.misc.NotNull;

public class StagiaireRequest {
	private Integer id;
	private String prenom;
	private String nom;
	private String email;
	@NotNull
	private Integer idFiliere;

	public StagiaireRequest() {

	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Integer getIdFiliere() {
		return idFiliere;
	}

	public void setIdFiliere(Integer idFiliere) {
		this.idFiliere = idFiliere;
	}

}
